#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdlib.h>
#include <stdio.h>
#include "symnmf.h"

/* Declare the shared global variables */
extern int n;
extern int d;
extern int k;
extern double** D;
extern double** W;
double** A;
double** X;

/* Declare the freeMatrix function */
void freeMatrix(double **matrix);


/* Helper function to convert a Python list to a 2D C array 
 * pyArray: Python object expected to be a list of lists.
 * rows: Number of rows in the array.
 * cols: Number of columns in the array.
 * Returns: the newly created 2D array, or NULL if an error occurs. */
static double** transformPyObjectToDoubleMatrix(PyObject* pyArray, int rows, int cols) {
    int rowIdx, colIdx, freeIdx;
    double** matrix = malloc(rows * sizeof(double*));
    /* Memory allocation error handling */
    if (!matrix) {
        PyErr_SetString(PyExc_MemoryError, "Unable to allocate memory for matrix rows");
        return NULL; }
    for (rowIdx = 0; rowIdx < rows; ++rowIdx) {
        matrix[rowIdx] = malloc(cols * sizeof(double));
        /* Free allocated memory on allocation failure */
        if (!matrix[rowIdx]) {
            PyErr_SetString(PyExc_MemoryError, "Memory allocation failed for a matrix row");
            for (freeIdx = 0; freeIdx < rowIdx; ++freeIdx) {
                free(matrix[freeIdx]); }
            free(matrix);
            return NULL; }
        /* Access the row in pyArray and validate it */
        PyObject* currentRow = PyList_GetItem(pyArray, rowIdx);
        if (!PyList_Check(currentRow) || PyList_Size(currentRow) != cols) {
            PyErr_SetString(PyExc_TypeError, "Expected a 2D list with correct dimensions");
            for (freeIdx = 0; freeIdx <= rowIdx; ++freeIdx) {
                free(matrix[freeIdx]); }
            free(matrix);
            return NULL; }
        /* Convert each element in the row to double */
        for (colIdx = 0; colIdx < cols; ++colIdx) {
            PyObject* element = PyList_GetItem(currentRow, colIdx);
            if (!PyFloat_Check(element)) {
                PyErr_SetString(PyExc_TypeError, "All elements must be floats");
                for (freeIdx = 0; freeIdx <= rowIdx; ++freeIdx) {
                    free(matrix[freeIdx]); }
                free(matrix);
                return NULL; }
            matrix[rowIdx][colIdx] = PyFloat_AsDouble(element); } }
    return matrix; }



/* Helper function to convert a 2D C array to a Python list
* Returns: a new Python list of lists (equivalent to a 2D array) 
* constructed from the provided double array, or NULL if an error occurs. 
*/
static PyObject* transformDoubleMatrixToPyObjectList(double** doubleArray, int rows, int cols) {
    PyObject* pyList = PyList_New(rows);  /*  Create a new Python list for rows */
    if (!pyList) {
        return NULL;  /* Memory allocation failed */
    }
    for (int rowIdx = 0; rowIdx < rows; ++rowIdx) {
        PyObject* rowList = PyList_New(cols);  /* Create a list for each row */
        if (!rowList) {
            Py_DECREF(pyList);
            return NULL;  /* Memory allocation failed */
        }
        for (int colIdx = 0; colIdx < cols; ++colIdx) {
            PyObject* pyValue = PyFloat_FromDouble(doubleArray[rowIdx][colIdx]);
            if (!pyValue) {
                Py_DECREF(pyList);
                Py_DECREF(rowList);
                return NULL;  /* Conversion failed */
            }
            PyList_SET_ITEM(rowList, colIdx, pyValue);  /* Add value to row */
        }
        PyList_SET_ITEM(pyList, rowIdx, rowList);  /* Add row to main list */
    }
    return pyList;
}


/* Python API for symC */
static PyObject* sym(PyObject *self, PyObject *args) {
    int i;
    PyObject* X_array;
    if (!PyArg_ParseTuple(args, "O", &X_array)) {
        return NULL;
    }

    n = PyList_Size(X_array);
    d = PyList_Size(PyList_GetItem(X_array, 0));
    X = transformPyObjectToDoubleMatrix(X_array, n, d);
    if (X == NULL) return NULL;

    A = symC(X);
    PyObject* py_result = transformDoubleMatrixToPyObjectList(A, n, n);

    /* Free memory */
    for (i = 0; i<n;i++) {
        if(X[i]!=NULL)
            free(X[i]);
    }
    if(X!=NULL)
        free(X);
    freeMatrix(A);
    return py_result;
}

/* Python API for normC */
static PyObject* norm(PyObject *self, PyObject *args) {
    PyObject* X_array;
    int i;
    if (!PyArg_ParseTuple(args, "O", &X_array)) {
        return NULL;
    }

    n = PyList_Size(X_array);
    d = PyList_Size(PyList_GetItem(X_array, 0));
    double** X = transformPyObjectToDoubleMatrix(X_array, n, d);
    if (X == NULL) return NULL;

    W = normC(X);
    PyObject* py_result = transformDoubleMatrixToPyObjectList(W, n, n);

    /* Free memory */
    for (i = 0; i<n;i++) {
        if(X[i]!=NULL)
            free(X[i]);
    }
    if(X!=NULL)
        free(X);
    freeMatrix(D);
    freeMatrix(W);
    return py_result;
}

/* Python API for ddgC */
static PyObject* ddg(PyObject *self, PyObject *args) {
    PyObject* X_array;
    int i;
    if (!PyArg_ParseTuple(args, "O", &X_array)) {
        return NULL;
    }

    n = PyList_Size(X_array);
    d = PyList_Size(PyList_GetItem(X_array, 0));
    double** X = transformPyObjectToDoubleMatrix(X_array, n, d);
    if (X == NULL) return NULL;

    D = ddgC(X);
    PyObject* py_result = transformDoubleMatrixToPyObjectList(D, n, n);

    /* Free memory */
    for (i = 0; i<n;i++) {
        if(X[i]!=NULL)
            free(X[i]);
    }
    if(X!=NULL)
        free(X);
    freeMatrix(D);
    return py_result;
}

/* Python API for symnmfC */
static PyObject* symnmf(PyObject *self, PyObject *args) {
    PyObject *H_array, *W_array;
    if (!PyArg_ParseTuple(args, "iOO", &k, &W_array, &H_array)) {
        return NULL;
    }
    W = transformPyObjectToDoubleMatrix(W_array, n, n);
    double** H = transformPyObjectToDoubleMatrix(H_array, n, k);

    if (W == NULL || H == NULL){
        return NULL;
    } 

    double** result = symnmfC(H);
    PyObject* py_result = transformDoubleMatrixToPyObjectList(result, n, k);
    /* Free memory */
    freeMatrix(W);
    freeMatrix(H);
    freeMatrix(result);
    return py_result;
}

static PyMethodDef symnmfMethods[] = {
    {"sym", (PyCFunction)sym, METH_VARARGS, PyDoc_STR("Generate similarity matrix A from X")},
    {"norm", (PyCFunction)norm, METH_VARARGS, PyDoc_STR("Compute the normalized similarity matrix W")},
    {"ddg", (PyCFunction)ddg, METH_VARARGS, PyDoc_STR("Compute the diagonal degree matrix D")},
    {"symnmf", (PyCFunction)symnmf, METH_VARARGS, PyDoc_STR("Perform Symmetric Nonnegative Matrix Factorization")},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef symnmfmodule = {
    PyModuleDef_HEAD_INIT,
    "symnmfmodule", /* name of module */
    NULL, /* module documentation, may be NULL */
    -1,  /* size of per-interpreter state of the module, or -1 if the module keeps state in global variables. */
    symnmfMethods /* the PyMethodDef array containing the methods of the extension */
};

PyMODINIT_FUNC PyInit_symnmfmodule(void) {
    return PyModule_Create(&symnmfmodule);
}
