#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "symnmf.h"

#define BETA 0.5
#define EPSILON 0.0001
#define MAX_ITER 300
#define MAX_LINE_SIZE 1024

int n;
int k;
int d;
int dim;
double** X;
double** W;
double** D;
double** A;
double** H;

double** allocateMatrix(int rows, int cols);

/* Computes the squared Euclidean distance between two points. */
double squaredEuclideanDistance(double *p, double *q, int d) {
    int i;
    double squared_sum = 0;
    for (i = 0; i < d; i++) {
        squared_sum += pow((p[i] - q[i]), 2);
    }
    return squared_sum;
}

/* Displays a matrix with specified rows and columns. */
static void displayMatrix(double** matrix, int rows, int cols) {
    int row, col;
    for (row = 0; row < rows; row++) {
        for (col = 0; col < cols; col++) {
            printf("%.4f", matrix[row][col]);
            if (col < cols - 1) {
                printf(",");
            } else {
                printf("\n");
            }
        }
    }
}

/* Counts the number of columns in a file. */
int countColumns(FILE *file) {
    int col_count = 1;
    int ch;
    
    while ((ch = fgetc(file)) != '\n' && ch != EOF) {
        if (ch == ',') {
            col_count++;
        }
    }
    rewind(file);
    return col_count;
}

/* Counts the number of rows in a file. */
int countRows(FILE *file) {
    int row_count = 0;
    char *buffer = NULL;
    size_t buffer_size = 0;

    while (getline(&buffer, &buffer_size, file) != -1) {
        row_count++;
    }
    free(buffer);
    rewind(file);
    return row_count;
}

/* Calculate and output the similarity matrix */
double** symC(double** X) {
    double *b;
    int i, j;
    b = calloc(n * n, sizeof(double));
    if (b == NULL) {
        printf("An Error Has Occurred");
        exit(1);
    }
    A = calloc(n, sizeof(double*));
    if (A == NULL) {
        printf("An Error Has Occurred");
        free(b);
        exit(1);
    }
    for (i = 0; i < n; i++) {
        A[i] = b + i * n;
    }
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if (i != j) {
                A[i][j] = exp(-0.5 * squaredEuclideanDistance(X[i], X[j], d)); /* as defined in the given formula */
            }
        }
    }
    return A;
}

/* Calculate the diagonal degree matrix */
double** ddgC(double** X) {
    double* b;
    double** D;
    int i, j;
    double d_i = 0.0;

    b = calloc(n * n, sizeof(double)); 
    if (b == NULL) {
        printf("An Error Has Occurred");
        exit(1);
    }
    D = calloc(n, sizeof(double*));
    if (D == NULL) {
        printf("An Error Has Occurred");
        free(b);
        exit(1);
    }

    A = symC(X);  /* Calculate the similarity matrix */

    for (i = 0; i < n; i++) {
        D[i] = b + i * n;
    }
    for (i = 0; i < n; i++) {
        d_i = 0.0;
        for (j = 0; j < n; j++) {
            d_i += A[i][j];
        }
        D[i][i] = d_i;
    }

    return D;
}

/* Calculate the normalized similarity matrix 
   The graph Laplacian W ∈ R n×n is defined as:
    W = D−1/2AD−1/2
*/
double** normC(double** X) {
    int row, col;
    W = allocateMatrix(n, n);  
    D = ddgC(X);  

    for (row = 0; row < n; row++) {
        for (col = 0; col < n; col++) {
            if (D[row][row] != 0 && D[col][col] != 0) {
                W[row][col] = A[row][col] * (1 / sqrt(D[row][row])) * (1 / sqrt(D[col][col]));
            } else {
                W[row][col] = 0.0;
            }
        }
    }

    return W;
}

/* Allocates memory for a matrix with contiguous storage */
double** allocateMatrix(int rows, int cols) {
    int i;
    double **matrix;
    double *data = calloc(rows * cols, sizeof(double));
    if (data == NULL){
        printf("An Error Has Occurred");
        exit(1);
    }
    matrix = calloc(rows, sizeof(double*));
    if (matrix==NULL) {
        printf("An Error Has Occurred");
        free(data);
        exit(1);
    }
    for (i = 0; i < rows; i++) {
        matrix[i] = data + i * cols;
    }
    return matrix;
}


/* Release memory allocated for a 2D matrix */
void freeMatrix(double **mat) {
    if (mat[0]!=NULL)  
        free(mat[0]);  
    if(mat!=NULL)
        free(mat);
}


/* Loads data points from a file and stores them in the global matrix X */
static double** readPointsFromFile(const char* fileName) {
    int i, j, r;
    FILE *file = fopen(fileName, "r");
    char *line = NULL;
    char *start, *end;
    size_t len = 0;
    if (!file) return NULL;
    d = countColumns(file);
    n = countRows(file);
    X = (double**)malloc(n * sizeof(double*));
    if (!X) { fclose(file); return NULL; }
    for (i = 0; i < n; i++) {
        X[i] = (double*)malloc(d * sizeof(double));
        if (!X[i]) {
            for (j = 0; j < i; j++) free(X[j]);
            free(X);
            fclose(file);
            return NULL; }
    }
    for (i = 0; i < n; i++) {
        if (getline(&line, &len, file) == -1) break;
        start = line;
        for (j = 0; j < d; j++) {
            X[i][j] = strtod(start, &end);
            if (start == end) {
                for (r = 0; r <= i; r++) free(X[r]);
                free(X);
                free(line);
                fclose(file);
                return NULL; }
            start = end;
            while (*start == ',') start++; }
    }
    free(line);
    fclose(file);
    return X; }

/*
 * Copies values from the source matrix to the destination matrix.
 *
 * destMatrix - the matrix that will receive the values
 * srcMatrix - the matrix providing values to be copied
 * rowCount - number of rows in each matrix
 * colCount - number of columns in each matrix
 * returns - 0 upon successful completion
 */
int copyMatrix(double **destMatrix, double **srcMatrix, int rowCount, int colCount) {
    int row, col;
    for (row = 0; row < rowCount; row++) {
        for (col = 0; col < colCount; col++) {
            destMatrix[row][col] = srcMatrix[row][col];
        }
    }
    return 0;
}


/* assigns the transpose matrix of matrix to a given matrix "transposedMatrix" of size l*m
* rows - size l
* cols - size m
* transposedMatrix - the matrix assigned values to
*/
void transposeMatrix(int rows, int cols, double** matrix, double*** transposedMatrix) {
    int i, j;
    /* aij = aji */
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            (*transposedMatrix)[j][i] = matrix[i][j];
        }
    }
}



/* Multiplies two matrices with specified dimensions and returns the result as a new matrix.
 * res - to store the result 
 * matrixA - First input matrix with dimensions numRowsA * numColsA
 * matrixB - Second input matrix with dimensions numColsA * numColsB
 * numRowsA - Number of rows in matrixA
 * numColsA - Number of columns in matrixA (and rows in matrixB)
 * numColsB - Number of columns in matrixB
 */
void matrixMultiply(double ***res ,double** matrixA, double** matrixB, int numRowsA, int numColsA, int numColsB) {
    int row, col, idx;
    double* data = calloc(numRowsA * numColsB, sizeof(double));
    /* Error handling for memory allocation */
    if (!data) {
        printf("An Error Has Occurred");
        exit(1);
    }
    *res = calloc(numRowsA, sizeof(double *));
    if (!(*res)) {
        printf("An Error Has Occurred");
        free(data);
        exit(1);
    }
    for (row = 0; row < numRowsA; row++)
        (*res)[row] = data + row * numColsB;
    /* Standard matrix multiplication algorithm */
    for (row = 0; row < numRowsA; row++) {
        for (col = 0; col < numColsB; col++) {
            for (idx = 0; idx < numColsA; idx++) {
                (*res)[row][col] += matrixA[row][idx] * matrixB[idx][col];
            }
        }
    }
}

/* Computes the squared Frobenius norm between two matrices
 * matA - the first matrix
 * matB - the second matrix
 * Returns - the squared Frobenius norm between matA and matB
 */
double calculateSquaredFrobeniusNorm(double** matA, double** matB) {
    int row, col;
    double sumDifferenceSquared = 0;

    for (row = 0; row < n; row++) {
        for (col = 0; col < k; col++) {
            double diff = matA[row][col] - matB[row][col];
            sumDifferenceSquared += diff * diff;
        }
    }

    return sumDifferenceSquared;
}

/* UpdateHWithSymmetricFactorization - updates matrix H based on iterative SymNMF algorithm
 * new_H - matrix to be updated
 * base_H - initial H matrix */
void UpdateH(double ***new_H, double **base_H) {
    int i, j;
    double **H_transpose = allocateMatrix(k, n);
    double **H_mult_Ht, **H_mult_HtH, **W_mult_H;
    freeMatrix(*new_H);
    *new_H = allocateMatrix(n, k);
    matrixMultiply(&W_mult_H,W, base_H, n, n, k);
    transposeMatrix(n, k, base_H, &H_transpose);
    matrixMultiply(&H_mult_Ht,base_H, H_transpose, n, k, n);
    matrixMultiply(&H_mult_HtH,H_mult_Ht, base_H, n, n, k);
    for (i = 0; i < n; i++) {
        for (j = 0; j < k; j++) {
            if (H_mult_HtH[i][j] == 0) {
                freeMatrix(*new_H);
                freeMatrix(W_mult_H);
                freeMatrix(H_transpose);
                freeMatrix(H_mult_Ht);
                freeMatrix(H_mult_HtH);
                printf("An Error Has Occurred");
                exit(1);
            }
            (*new_H)[i][j] = base_H[i][j] * (1 - BETA + (BETA * (W_mult_H[i][j] / H_mult_HtH[i][j])));
        }
    }
    freeMatrix(W_mult_H);
    freeMatrix(H_transpose);
    freeMatrix(H_mult_Ht);
    freeMatrix(H_mult_HtH);
}

/* Performs Symmetric Nonnegative Matrix Factorization (SymNMF) with iterative updates.
 * prev_H - The initial matrix H
 * Returns - The final H matrix containing clustering information
 */
double** symnmfC(double **prev_H) {
    int iter_count;
    double **final_H;
    double *allocated_mem = calloc(n * k, sizeof(double));
    /* Error handling for memory allocation */
    if (!allocated_mem) {
        printf("An Error Has Occurred");
        exit(1);
    }
    final_H = calloc(n, sizeof(double *));
    if (!final_H) {
        printf("An Error Has Occurred");
        free(allocated_mem);
        exit(1);
    }
    /* Initialize pointers for matrix rows */
    for (iter_count = 0; iter_count < n; iter_count++) {
        final_H[iter_count] = allocated_mem + iter_count * k;
    }
    /* Perform iterative updates on H */
    for (iter_count = 0; iter_count < MAX_ITER; iter_count++) {
        UpdateH(&final_H, prev_H);
        /* Check for convergence */
        if (calculateSquaredFrobeniusNorm(prev_H, final_H) < EPSILON) {
            break;
        }
        /* Copy updated matrix to prev_H for next iteration */
        copyMatrix(prev_H, final_H, n, k);
    }
    return final_H;
}

int main(int argc, char* argv[]) {
    const char* goal;
    const char* filename;
    double** result;
    int i;
    if (argc != 3) {
        printf("An Error Has Occurred");
        return 1; }
    goal = argv[1];
    filename = argv[2];
    X = readPointsFromFile(filename); /* read the points from the given file */
    if (X==NULL) {
        printf("An Error Has Occurred");
        exit(1); }
    if (strcmp(goal, "sym") == 0) {
        result = symC(X);
        displayMatrix(result, n, n);
        freeMatrix(result); }  
    else if (strcmp(goal, "ddg") == 0) { 
        result = ddgC(X);
        displayMatrix(result, n, n);
        freeMatrix(A);
        freeMatrix(result); }
    else if (strcmp(goal, "norm") == 0) {
        result = normC(X);
        displayMatrix(result, n, n);
        freeMatrix(result);
        freeMatrix(D);
        freeMatrix(A); }
    else { /* not each of the cases */
        printf("An Error Has Occurred");
        freeMatrix(X);
        return 1; }
    for (i = 0; i<n;i++) {
        if(X[i]!=NULL)
            free(X[i]); }
    if(X!=NULL)
        free(X);
    return 0; }


