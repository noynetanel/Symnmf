/**
 * Calculates the symmetric similarity matrix (A) using the Euclidean distance formula.
 * 
 * The similarity between two points is computed as:
 * A[i][j] = exp(-0.5 * squared_euclidean_distance(X[i], X[j]))
 * 
 * @param X The input matrix containing data points of size (n x d), where:
 *          - n is the number of data points
 *          - d is the dimensionality of each data point
 * @return A symmetric similarity matrix of size (n x n), where A[i][j] represents the similarity between points i and j.
 */
double** symC(double**);

/**
 * Computes the diagonal degree matrix (D) from the similarity matrix (A).
 * 
 * Each diagonal entry D[i][i] is the sum of the corresponding row in A:
 * D[i][i] = Σ A[i][j] for all j
 * 
 * @param X The input matrix containing data points of size (n x d).
 * @return A diagonal degree matrix of size (n x n).
 */
double** ddgC(double**);

/**
 * Computes the normalized similarity matrix (W) using the formula:
 * W = D^(−1/2)AD^(−1/2)
 * The normalized matrix accounts for degree scaling to improve numerical stability.
 * 
 * @param X The input matrix containing data points of size (n x d).
 * @return A normalized similarity matrix of size (n x n).
 */
double** normC(double**);

/**
 * Performs Symmetric Nonnegative Matrix Factorization (SymNMF).
 * 
 * The algorithm decomposes the normalized similarity matrix (W) into the form:
 * W ≈ H * H^T, where H is an affiliation matrix.
 * 
 * This is achieved through iterative updates of H until convergence or the maximum number of iterations is reached.
 * 
 * @param prev_H The initial affiliation matrix (H) of size (n x k), where:
 *               - n is the number of data points
 *               - k is the number of clusters
 * @return The final affiliation matrix (H) after factorization.
 */
double** symnmfC(double**);
